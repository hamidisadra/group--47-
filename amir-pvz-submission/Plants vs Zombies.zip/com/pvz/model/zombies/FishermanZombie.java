package com.pvz.model.zombies;

import com.pvz.model.core.Plant;
import com.pvz.model.core.Zombie;

public class FishermanZombie extends Zombie {
    public boolean staysInRightmostColumn;
    public float hookCooldownSeconds;
    public FishermanZombie() {
        super("FishermanZombie");
        this.staysInRightmostColumn = true;
        this.hookCooldownSeconds = 2.5f;
    }
    public void hookPlantOneTileRight(Plant plant) {
        if (plant != null && plant.location != null) {
            plant.location.x++;
            plant.positionX = plant.location.x;
        }
    }
    public void throwAdjacentHookedPlant(Plant plant) {
        if (plant != null) {
            plant.die();
        }
    }
}
